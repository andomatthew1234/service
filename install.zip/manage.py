import tkinter as tk
from tkinter import messagebox, filedialog
import os

CONTROL_FILE = "control.txt"

def browse_file():
    """Opens a file dialog and automatically normalizes the path using environment variables."""
    file_path = filedialog.askopenfilename(
        title="Select any Application",
        filetypes=[("Executables", "*.exe"), ("Shortcuts", "*.lnk"), ("All Files", "*.*")]
    )
    if file_path:
        clean_path = os.path.normpath(file_path)
        user_profile = os.environ.get('USERPROFILE', '')
        
        if user_profile and clean_path.lower().startswith(user_profile.lower()):
            relative_part = clean_path[len(user_profile):]
            clean_path = f"%USERPROFILE%{relative_part}"
            
        app_entry.delete(0, tk.END)
        app_entry.insert(0, clean_path)
        status_label.config(text="Loaded and universalized application path.", fg="#1e90ff")

def save_changes():
    shutdown_status = shutdown_var.get()
    app_path = app_entry.get().strip()
    
    if not app_path:
        app_path = "none"
        
    formatted_data = f"{shutdown_status},{app_path}"
    
    try:
        with open(CONTROL_FILE, "w") as file:
            file.write(formatted_data)
        status_label.config(text="Saved successfully to control.txt", fg="#2ed573")
    except Exception as e:
        messagebox.showerror("Error", f"Could not write to file: {e}")

def load_current_status():
    if os.path.exists(CONTROL_FILE):
        try:
            with open(CONTROL_FILE, "r") as file:
                content = file.read().strip()
                if "," in content:
                    shutdown_part, app_part = content.split(",", 1)
                    shutdown_var.set(shutdown_part.strip().lower())
                    app_entry.delete(0, tk.END)
                    if app_part.strip().lower() != "none":
                        app_entry.insert(0, app_part.strip())
        except Exception:
            pass

# --- GUI Setup ---
root = tk.Tk()
root.title("C2 System Control Center")
root.geometry("500x340")
root.configure(bg="#2f3542")

title = tk.Label(root, text="Remote System Manager", font=("Helvetica", 16, "bold"), fg="#ffffff", bg="#2f3542")
title.pack(pady=15)

shutdown_frame = tk.LabelFrame(root, text=" Target Machine Power State ", fg="#a4b0be", bg="#2f3542", padx=10, pady=5)
shutdown_frame.pack(fill="x", padx=20, pady=5)

shutdown_var = tk.StringVar(value="false")
rb_false = tk.Radiobutton(shutdown_frame, text="Keep PC Running (false)", variable=shutdown_var, value="false", fg="#ffffff", bg="#2f3542", selectcolor="#2f3542")
rb_false.pack(anchor="w")
rb_true = tk.Radiobutton(shutdown_frame, text="FORCE SHUTDOWN (true)", variable=shutdown_var, value="true", fg="#ff4757", bg="#2f3542", selectcolor="#2f3542")
rb_true.pack(anchor="w")

app_frame = tk.LabelFrame(root, text=" Application Target Path ", fg="#a4b0be", bg="#2f3542", padx=10, pady=10)
app_frame.pack(fill="x", padx=20, pady=10)

app_entry = tk.Entry(app_frame, font=("Helvetica", 10), width=30)
app_entry.pack(side="left", padx=5, fill="x", expand=True)

browse_btn = tk.Button(app_frame, text="Browse PC...", command=browse_file, bg="#747d8c", fg="#ffffff", font=("Helvetica", 9, "bold"))
browse_btn.pack(side="right", padx=5)

save_btn = tk.Button(root, text="COMMIT CHANGES TO FILE", command=save_changes, bg="#2ed573", fg="#ffffff", font=("Helvetica", 11, "bold"), pady=6)
save_btn.pack(fill="x", padx=20, pady=15)

status_label = tk.Label(root, text="Awaiting system inputs...", fg="#a4b0be", bg="#2f3542", font=("Helvetica", 9, "italic"))
status_label.pack(pady=5)

load_current_status()
root.mainloop()